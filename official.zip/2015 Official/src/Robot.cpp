#include "WPILib.h"

class Robot: public IterativeRobot
{
public:
	Robot();
	~Robot();


	RobotDrive* myRobot;
	Joystick* lStick;
	Joystick* rStick;
	Talon* talon1;
	Talon* talon2;

private:
	LiveWindow *lw;


	void RobotInit();
	void AutonomousInit();
	void AutonomousPeriodic();
	void TeleopInit();
	void TeleopPeriodic();
	void TestPeriodic();


};

Robot::Robot()
{
	lw = LiveWindow::GetInstance();

	talon1 = new Talon(0);
	talon2 = new Talon(2);

	lStick = new Joystick(0);
	rStick = new Joystick(1);

	myRobot = new RobotDrive(talon1, talon2);

	myRobot->SetExpiration(0.1);

};

Robot::~Robot()
{
	delete talon1;
	delete talon2;

	delete lStick;
	delete rStick;

}




void Robot::RobotInit()
{

}

void Robot::AutonomousInit()
{

}

void Robot::AutonomousPeriodic()
{

}

void Robot::TeleopInit()
{

}

void Robot::TeleopPeriodic()
{

	//arcade drive
	myRobot->ArcadeDrive(lStick);

	//tank drive
	//myRobot->TankDrive(lStick, rStick);
}

void Robot::TestPeriodic()
{
	lw->Run();
}

START_ROBOT_CLASS(Robot);
